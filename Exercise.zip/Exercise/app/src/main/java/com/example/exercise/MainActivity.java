package com.example.exercise;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    WebView simpleWebView;
    Button loadExercise;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //initiate buttons and web view
        loadExercise = (Button) findViewById(R.id.loadExercise);
        loadExercise.setOnClickListener(this);
        simpleWebView = (WebView) findViewById((R.id.simpleWebView));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.loadExercise:
                simpleWebView.setWebViewClient(new MyWebViewClient());
                String url="https://www.healthline.com/health/fitness-exercises/10-best-exercises-everyday#how-to-improve";
                simpleWebView.getSettings().setJavaScriptEnabled(true);
                simpleWebView.loadUrl(url); //load web page in web view
                break;
        }
    }
    private class MyWebViewClient extends WebViewClient
    {
        @Override
        public boolean shouldOverrideUrlLoading (WebView view, String url)
        {
            view.loadUrl(url);
            return true;
        }
    }
}
